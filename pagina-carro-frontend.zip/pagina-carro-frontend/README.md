# AutoShow - Página de Carros

Uma página web moderna e responsiva com tema de carros, desenvolvida com **HTML5, CSS3 e JavaScript vanilla** (sem frameworks ou build tools).

## 📁 Estrutura do Projeto

```
pagina-carro-frontend/
├── index.html          # Arquivo HTML principal
├── css/
│   └── styles.css      # Estilos CSS completos
├── js/
│   └── script.js       # Scripts JavaScript
├── images/             # Pasta para imagens (vazia)
└── README.md           # Este arquivo
```

## 🚀 Como Usar

### Opção 1: Abrir Localmente
1. Clone ou baixe este repositório
2. Abra o arquivo `index.html` diretamente no navegador
3. Pronto! A página está funcionando

### Opção 2: Usar um Servidor Local
Se preferir usar um servidor local (recomendado):

```bash
# Com Python 3
python -m http.server 8000

# Com Python 2
python -m SimpleHTTPServer 8000

# Com Node.js (http-server)
npx http-server

# Com PHP
php -S localhost:8000
```

Depois acesse: `http://localhost:8000`

## ✨ Funcionalidades

### 🎨 Design e Layout
- **Tema Escuro Elegante** - Cores em tons de azul, cinza e branco
- **Gradientes Modernos** - Efeitos visuais sofisticados
- **Design Responsivo** - Funciona perfeitamente em mobile, tablet e desktop
- **Animações Suaves** - Transições e efeitos de hover

### 📱 Seções da Página

1. **Navegação Sticky** - Menu superior que fica fixo ao rolar
2. **Hero Section** - Seção de destaque com chamada para ação
3. **Galeria de Carros** - 3 modelos com especificações técnicas
4. **Especificações** - 4 cards com diferenciais dos carros
5. **Formulário de Contato** - Captura de interesse com validação
6. **Footer** - Rodapé com informações

### 🎯 Funcionalidades JavaScript

- ✅ Smooth scroll para links de navegação
- ✅ Validação de formulário com feedback
- ✅ Efeito ripple em botões
- ✅ Animação de entrada ao scroll (Intersection Observer)
- ✅ Sombra dinâmica na navbar
- ✅ Interatividade nos cards

## 🎨 Cores Utilizadas

| Cor | Código | Uso |
|-----|--------|-----|
| Azul Primário | `#3b82f6` | Botões, links, destaque |
| Azul Escuro | `#1e40af` | Hover de botões |
| Ciano | `#06b6d4` | Gradientes, preços |
| Fundo | `#0f172a` | Background principal |
| Superfície | `#1e293b` | Cards, formulário |
| Texto | `#ffffff` | Texto principal |

## 📊 Modelos de Carros

1. **Speedster GT** - R$ 250.000
   - Potência: 450 HP
   - Velocidade: 280 km/h
   - Consumo: 8.5 L/100km

2. **Urban Pro** - R$ 150.000
   - Potência: 200 HP
   - Velocidade: 200 km/h
   - Consumo: 6.2 L/100km

3. **Luxury Elite** - R$ 380.000
   - Potência: 550 HP
   - Velocidade: 300 km/h
   - Consumo: 10.5 L/100km

## 🛠️ Tecnologias Utilizadas

- **HTML5** - Estrutura semântica
- **CSS3** - Estilos, gradientes, animações, media queries
- **JavaScript Vanilla** - Interatividade sem dependências
- **Intersection Observer API** - Animações ao scroll
- **Flexbox e CSS Grid** - Layouts responsivos

## 📱 Compatibilidade

- ✅ Chrome/Chromium (versão 51+)
- ✅ Firefox (versão 55+)
- ✅ Safari (versão 12.1+)
- ✅ Edge (versão 79+)
- ✅ Dispositivos móveis (iOS e Android)

## 🔧 Customização

### Alterar Cores
Edite as variáveis CSS no início do arquivo `css/styles.css`:

```css
:root {
    --primary-color: #3b82f6;
    --secondary-color: #06b6d4;
    /* ... outras cores ... */
}
```

### Adicionar Novos Carros
Copie um bloco `car-card` no HTML e atualize as informações:

```html
<div class="car-card">
    <div class="car-emoji-large">🏎️</div>
    <h3 class="car-title">Nome do Carro</h3>
    <p class="car-price">R$ Preço</p>
    <!-- ... especificações ... -->
</div>
```

### Modificar Textos
Todos os textos estão no arquivo `index.html` e podem ser facilmente alterados.

## 📝 Notas Importantes

- Não há dependências externas - funciona 100% offline
- O formulário de contato é apenas front-end (não envia dados para servidor)
- Para integração com backend, modifique a função `handleSubmit` em `js/script.js`
- As imagens dos carros usam emojis (podem ser substituídas por imagens reais)

## 🚀 Próximos Passos

Para melhorar ainda mais a página:

1. **Backend** - Integrar com servidor para processar formulários
2. **Banco de Dados** - Armazenar mensagens de contato
3. **Email** - Enviar confirmações por email
4. **Analytics** - Rastrear visitantes
5. **SEO** - Otimizar para mecanismos de busca
6. **PWA** - Tornar instalável como app

## 📄 Licença

Este projeto é de código aberto e pode ser usado livremente.

## 👨‍💻 Desenvolvido com ❤️

Desenvolvido como exemplo de página front-end moderna com HTML, CSS e JavaScript puro.

---

**Dúvidas?** Sinta-se livre para explorar o código e adaptá-lo às suas necessidades!
