# Project TODO

## Features
- [x] Página inicial com tema de carros
- [x] Seção de galeria de carros (3 modelos)
- [x] Seção de especificações técnicas
- [x] Formulário de contato/interesse
- [x] Design responsivo (mobile, tablet, desktop)
- [x] Animações e efeitos visuais
- [x] Navegação intuitiva com menu sticky
- [x] Tema escuro elegante com gradientes
- [x] Ícones e emojis temáticos
- [x] Cards com especificações técnicas
- [x] Footer com informações
