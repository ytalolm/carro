import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ChevronRight, Zap, Gauge, Fuel, Users } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });

  const cars = [
    {
      id: 1,
      name: "Speedster GT",
      price: "R$ 250.000",
      image: "🏎️",
      specs: { power: "450 HP", speed: "280 km/h", fuel: "8.5 L/100km" },
    },
    {
      id: 2,
      name: "Urban Pro",
      price: "R$ 150.000",
      image: "🚗",
      specs: { power: "200 HP", speed: "200 km/h", fuel: "6.2 L/100km" },
    },
    {
      id: 3,
      name: "Luxury Elite",
      price: "R$ 380.000",
      image: "🚙",
      specs: { power: "550 HP", speed: "300 km/h", fuel: "10.5 L/100km" },
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Obrigado ${formData.name}! Entraremos em contato em breve.`);
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-700">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-2xl font-bold">
            <span>🏁</span>
            <span>AutoShow</span>
          </div>
          <div className="flex items-center gap-6">
            <a href="#cars" className="hover:text-blue-400 transition">Carros</a>
            <a href="#specs" className="hover:text-blue-400 transition">Especificações</a>
            <a href="#contact" className="hover:text-blue-400 transition">Contato</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                Experiência de <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">Velocidade</span>
              </h1>
              <p className="text-xl text-slate-300">
                Descubra nossa coleção exclusiva de veículos de alta performance. Tecnologia, design e adrenalina em perfeita harmonia.
              </p>
              <div className="flex gap-4">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
                  Explorar Catálogo <ChevronRight className="ml-2" />
                </Button>
                <Button variant="outline" className="border-slate-400 text-white hover:bg-slate-800 px-8 py-6 text-lg">
                  Agendar Test Drive
                </Button>
              </div>
            </div>
            <div className="text-center">
              <div className="text-9xl animate-bounce">🏎️</div>
              <p className="text-slate-400 mt-4">Speedster GT - Nosso Destaque</p>
            </div>
          </div>
        </div>
      </section>

      {/* Cars Gallery */}
      <section id="cars" className="py-20 bg-slate-800/50">
        <div className="container max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-4">Nossa Frota</h2>
          <p className="text-slate-300 mb-12">Conheça os modelos disponíveis</p>
          
          <div className="grid md:grid-cols-3 gap-6">
            {cars.map((car) => (
              <Card key={car.id} className="bg-slate-700 border-slate-600 hover:border-blue-500 transition overflow-hidden group">
                <CardHeader>
                  <div className="text-6xl mb-4 group-hover:scale-110 transition">{car.image}</div>
                  <CardTitle className="text-white">{car.name}</CardTitle>
                  <CardDescription className="text-blue-400 text-lg font-semibold">{car.price}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-slate-300">
                      <Zap className="w-4 h-4 text-yellow-400" />
                      <span>Potência: {car.specs.power}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <Gauge className="w-4 h-4 text-red-400" />
                      <span>Velocidade: {car.specs.speed}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <Fuel className="w-4 h-4 text-green-400" />
                      <span>Consumo: {car.specs.fuel}</span>
                    </div>
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Saiba Mais</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Specs Section */}
      <section id="specs" className="py-20">
        <div className="container max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12">Por Que Escolher Nossos Carros?</h2>
          
          <div className="grid md:grid-cols-4 gap-6">
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 hover:border-blue-500 transition">
              <Zap className="w-8 h-8 text-yellow-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Alta Performance</h3>
              <p className="text-slate-300">Motores potentes com tecnologia de ponta</p>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 hover:border-blue-500 transition">
              <Users className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Conforto Total</h3>
              <p className="text-slate-300">Interior luxuoso e espaçoso para toda família</p>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 hover:border-blue-500 transition">
              <Gauge className="w-8 h-8 text-red-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Segurança</h3>
              <p className="text-slate-300">Sistemas avançados de proteção e assistência</p>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 hover:border-blue-500 transition">
              <Fuel className="w-8 h-8 text-green-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Eficiência</h3>
              <p className="text-slate-300">Consumo otimizado e economia de combustível</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-slate-800/50">
        <div className="container max-w-2xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-4">Entre em Contato</h2>
          <p className="text-slate-300 mb-8">Tem interesse em algum dos nossos veículos? Deixe seus dados!</p>
          
          <Card className="bg-slate-700 border-slate-600">
            <CardContent className="pt-6">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Nome</label>
                  <Input
                    type="text"
                    placeholder="Seu nome completo"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="bg-slate-600 border-slate-500 text-white placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <Input
                    type="email"
                    placeholder="seu@email.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    className="bg-slate-600 border-slate-500 text-white placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Mensagem</label>
                  <Textarea
                    placeholder="Qual carro te interessa? Tem alguma dúvida?"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="bg-slate-600 border-slate-500 text-white placeholder:text-slate-400"
                  />
                </div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg">
                  Enviar Mensagem
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-700 py-8">
        <div className="container max-w-6xl mx-auto px-4 text-center text-slate-400">
          <p>&copy; 2024 AutoShow. Todos os direitos reservados.</p>
          <p className="text-sm mt-2">Desenvolvido com ❤️ para os amantes de carros</p>
        </div>
      </footer>
    </div>
  );
}
